/* ============================================================
   Hiwar (حوار) — front-end logic
   ============================================================ */
'use strict';

/* ---------------- i18n ---------------- */
const I18N = {
  ar: {
    inputPlaceholder: 'ماذا تريد أن تفعل؟',
    voiceTryLabel: '🎙️ محادثة صوتية',
    chatTitleNew: 'hiwar',
    newChat: 'محادثة جديدة',
    clearAll: 'مسح كل المحادثات',
    settings: 'الإعدادات',
    provider: 'مزوّد الذكاء الاصطناعي',
    providerDemo: 'وضع تجريبي (بدون مفتاح)',
    providerOpenAI: 'OpenAI / متوافق (GPT…)',
    providerGemini: 'Google Gemini — مجاني',
    providerGroq: 'Groq — مجاني وسريع',
    providerOpenRouter: 'OpenRouter — نماذج مجانية',
    providerAnthropic: 'Anthropic Claude',
    apiKey: 'مفتاح API',
    model: 'النموذج',
    systemPrompt: 'تعليمات النظام (الشخصية)',
    voiceSettings: 'إعدادات الصوت',
    voiceEngine: 'محرك الصوت',
    engineGoogle: 'Google بشري — الأفضل (يحتاج إنترنت)',
    engineSystem: 'جهازي — يعمل بدون إنترنت',
    autoSpeak: 'قراءة ردود المساعد صوتياً',
    voiceLang: 'لغة الصوت',
    voicePick: 'اختيار الصوت',
    rate: 'السرعة',
    pitch: 'الطبقة',
    reset: 'إعادة الضبط',
    save: 'حفظ الإعدادات',
    listening: 'أستمع إليك…',
    micWaiting: 'سيطلب متصفحك الإذن باستخدام الميكروفون — اسمح به للمتابعة 🎙️',
    speaking: 'يقرأ الرد…',
    busy: 'يرجى انتظار اكتمال الرد الحالي.',
    micNotSupported: 'متصفحك لا يدعم التعرّف على الصوت — جرّب Chrome أو Edge.',
    ttsNotSupported: 'متصفحك لا يدعم النطق الصوتي.',
    ttsFailed: 'تعذّر تشغيل الصوت في هذا المتصفح.',
    micDenied: 'تم رفض إذن الميكروفون — اسمح بالوصول إليه من إعدادات المتصفح.',
    micNoSpeech: 'لم أسمع أي كلام — حاول مرة أخرى بوضوح.',
    micAudioCapture: 'تعذّر التقاط الصوت — تأكد من اتصال الميكروفون.',
    micNetwork: 'مشكلة في الشبكة أثناء التعرّف على الصوت.',
    micLang: 'اللغة المختارة غير مدعومة للتعرّف على الصوت.',
    voiceChatMode: 'محادثة صوتية مستمرة (يستمع تلقائياً بعد كل رد)',
    voiceGreeting: 'أهلاً بك في المحادثة الصوتية 🎙️ — تحدث معي بحرية وسأرد عليك صوتياً.',
    voiceModeOn: 'تم تفعيل المحادثة الصوتية المستمرة 🎙️',
    voiceModeOff: 'تم إيقاف المحادثة الصوتية المستمرة 🔇',
    bigMicLabel: 'تحدث معي',
    voiceModeBannerOn: 'وضع المحادثة الصوتية مفعّل — تحدث بحرية وسأرد عليك صوتياً',
    fontPick: 'خط الواجهة',
    testVoice: 'تجربة الصوت',
    noVoices: 'لا توجد أصوات متاحة — سيُستخدم الصوت الافتراضي.',
    serverFallback: 'تعذّر الاتصال بالخادم — تم التحويل إلى الوضع التجريبي.',
    serverDown: 'الخادم غير متصل حالياً — حدّث الصفحة أو أعد المحاولة خلال لحظات.',
    serverBack: 'عاد الاتصال بالخادم ✓',
    offlineMode: 'وضع الطوارئ المحلي (بدون اتصال بالخادم)',
    offlineHint: 'سيعود الذكاء الكامل تلقائياً فور عودة الاتصال.',
    saved: 'تم حفظ الإعدادات ✓',
    keyMissing: 'يرجى إضافة مفتاح API من الإعدادات ⚙️',
    errorOccurred: 'حدث خطأ ما.',
    badKey: 'المفتاح غير صحيح — تحقق منه في الإعدادات ⚙️',
    lowCredit: 'رصيد حسابك منخفض — اشحن الرصيد أو بدّل المزوّد من الإعدادات ⚙️',
    quota: 'استنفدت الحصة المجانية اليومية — جرّب مزوّداً آخر من الإعدادات ⚙️',
    quotaCountdown: 'الحصة ممتلئة مؤقتاً — إعادة المحاولة تلقائياً خلال {n} ثانية…',
    rateLimit: 'طلبات كثيرة بسرعة — انتظر قليلاً ثم أعد المحاولة.',
    badModel: 'اسم النموذج غير صحيح — عدّله في الإعدادات ⚙️',
    demoFallback: 'تعذّر الوصول للمزوّد — سأرد عليك بالوضع التجريبي الآن.',
    deleted: 'تم حذف المحادثة.',
    cleared: 'تم مسح جميع المحادثات.',
    voiceOn: 'تم تفعيل الرد الصوتي 🔊',
    voiceOff: 'تم إيقاف الرد الصوتي 🔇',
    you: 'أ',
    ai: 'ح',
    emptyTitle: 'كيف أساعدك اليوم؟',
    emptySub: 'اسألني أي شيء، أو تحدّث معي بالصوت.',
    composerFoot: 'HIWAR AI — قد يخطئ أحياناً، تحقق من المعلومات المهمة.',
    statusOnline: 'متصل',
    statusDemo: 'وضع تجريبي',
    chips: [
      { q: 'اكتب لي قصيدة عن الجمال', label: '✍️ اكتب لي قصيدة' },
      { q: 'اشرح لي الذكاء الاصطناعي ببساطة', label: '🧠 اشرح لي الذكاء الاصطناعي' },
      { q: 'قدّم لي نصيحة لبدء يومي بنشاط', label: '🌅 نصيحة لصباحي' },
      { q: 'أخبرني نكتة ذكية', label: '😄 نكتة ذكية' },
    ],
  },
  en: {
    inputPlaceholder: 'what do you want to do ?',
    voiceTryLabel: '🎙️ Voice chat',
    chatTitleNew: 'hiwar',
    newChat: 'New chat',
    clearAll: 'Clear all conversations',
    settings: 'Settings',
    provider: 'AI provider',
    providerDemo: 'Demo mode (no key)',
    providerOpenAI: 'OpenAI / compatible (GPT…)',
    providerGemini: 'Google Gemini — free',
    providerGroq: 'Groq — free & fast',
    providerOpenRouter: 'OpenRouter — free models',
    providerAnthropic: 'Anthropic Claude',
    apiKey: 'API key',
    model: 'Model',
    systemPrompt: 'System instructions (persona)',
    voiceSettings: 'Voice settings',
    voiceEngine: 'Voice engine',
    engineGoogle: 'Google human-like — best (needs internet)',
    engineSystem: 'On-device — works offline',
    autoSpeak: 'Read assistant replies aloud',
    voiceLang: 'Voice language',
    voicePick: 'Voice',
    rate: 'Speed',
    pitch: 'Pitch',
    reset: 'Reset',
    save: 'Save settings',
    listening: 'Listening to you…',
    micWaiting: 'Your browser will ask for microphone permission — allow it to continue 🎙️',
    speaking: 'Reading the reply…',
    busy: 'Please wait for the current reply to finish.',
    micNotSupported: 'Your browser does not support voice recognition — try Chrome or Edge.',
    ttsNotSupported: 'Your browser does not support speech synthesis.',
    ttsFailed: 'Could not play audio in this browser.',
    micDenied: 'Microphone permission was denied — allow it in your browser settings.',
    micNoSpeech: 'I did not hear any speech — please try again clearly.',
    micAudioCapture: 'Could not capture audio — check your microphone.',
    micNetwork: 'Network issue during speech recognition.',
    micLang: 'The selected language is not supported for speech recognition.',
    voiceChatMode: 'Continuous voice chat (auto-listens after each reply)',
    voiceGreeting: 'Welcome to voice conversation 🎙️ — speak freely and I will reply out loud.',
    voiceModeOn: 'Continuous voice conversation enabled 🎙️',
    voiceModeOff: 'Continuous voice conversation disabled 🔇',
    bigMicLabel: 'Talk to me',
    voiceModeBannerOn: 'Voice conversation mode is on — speak freely and I will reply out loud',
    fontPick: 'Interface font',
    testVoice: 'Test voice',
    noVoices: 'No voices available — default voice will be used.',
    serverFallback: 'Could not reach the server — switched to demo mode.',
    serverDown: 'The server is offline right now — refresh the page or try again shortly.',
    serverBack: 'Server connection restored ✓',
    offlineMode: 'Emergency local mode (no server connection)',
    offlineHint: 'Full AI will resume automatically once the connection returns.',
    saved: 'Settings saved ✓',
    keyMissing: 'Please add an API key in Settings ⚙️',
    errorOccurred: 'Something went wrong.',
    badKey: 'Invalid API key — check it in Settings ⚙️',
    lowCredit: 'Account credit is too low — top up or switch provider in Settings ⚙️',
    quota: 'Daily free quota exhausted — try another provider in Settings ⚙️',
    quotaCountdown: 'Quota temporarily full — retrying automatically in {n}s…',
    rateLimit: 'Too many requests — wait a moment and try again.',
    badModel: 'Invalid model name — fix it in Settings ⚙️',
    demoFallback: 'Could not reach the provider — I will reply in demo mode for now.',
    deleted: 'Conversation deleted.',
    cleared: 'All conversations cleared.',
    voiceOn: 'Voice replies enabled 🔊',
    voiceOff: 'Voice replies disabled 🔇',
    you: 'Y',
    ai: 'H',
    emptyTitle: 'How can I help you today?',
    emptySub: 'Ask me anything, or just talk to me.',
    composerFoot: 'HIWAR AI — can make mistakes, verify important information.',
    statusOnline: 'Online',
    statusDemo: 'Demo mode',
    chips: [
      { q: 'Write me a poem about beauty', label: '✍️ Write me a poem' },
      { q: 'Explain AI to me simply', label: '🧠 Explain AI simply' },
      { q: 'Give me advice to start my day energized', label: '🌅 Morning advice' },
      { q: 'Tell me a clever joke', label: '😄 A clever joke' },
    ],
  },
};

const DEFAULT_SETTINGS = {
  provider: 'gemini',
  baseUrl: 'https://api.openai.com/v1',
  apiKey: '',
  model: 'gemini-3.6-flash',
  systemPrompt: '',
  autoSpeak: true,
  voiceChatMode: false,
  voiceEngine: 'google',
  voiceLang: 'ar-SA',
  voiceURI: '',
  rate: 1,
  pitch: 1,
  fontFamily: 'hajar',
};

/* ---------------- state ---------------- */
let lang = localStorage.getItem('hiwar.lang') || 'ar';
let settings = { ...DEFAULT_SETTINGS, ...safeJSON(localStorage.getItem('hiwar.settings.v2'), {}) };
let convs = safeJSON(localStorage.getItem('hiwar.convs'), {});
let currentId = localStorage.getItem('hiwar.currentId') || null;

let streaming = false;
let streamCancel = null;
let recognition = null;
let voices = [];
let noSpeechRetries = 0;
let micListening = false;      // هل المايك يستمع الآن
let micPermissionAsked = false; // هل طُلب إذن الميكروفون من قبل
let speakQueue = [];            // قائمة جمل النطق الصوتي
let speakingNow = false;
let speechGen = 0;              // جيل التشغيل الصوتي (لإلغاء التشغيل القديم)
let currentAudio = null;        // عنصر الصوت الجاري تشغيله (محرك Google)

const $ = (id) => document.getElementById(id);

/* ---------------- helpers ---------------- */
function safeJSON(str, fallback) {
  try { const v = JSON.parse(str); return v ?? fallback; } catch { return fallback; }
}
function t(key) { return (I18N[lang] && I18N[lang][key]) || key; }
function isArabic(text) { return /[\u0600-\u06FF]/.test(text); }
function nowTime() {
  return new Date().toLocaleTimeString(lang === 'ar' ? 'ar-SA' : 'en-US', { hour: '2-digit', minute: '2-digit' });
}
function uid() { return 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

function saveConvs() { localStorage.setItem('hiwar.convs', JSON.stringify(convs)); }
function saveSettings() { localStorage.setItem('hiwar.settings.v2', JSON.stringify(settings)); }
function saveCurrent() { localStorage.setItem('hiwar.currentId', currentId); }

const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));

function toast(msg, type) {
  const el = document.createElement('div');
  el.className = 'toast' + (type ? ' ' + type : '');
  el.textContent = msg;
  $('toastWrap').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; }, 2600);
  setTimeout(() => el.remove(), 3100);
}

function updateStatusText() {
  const p = settings.provider;
  if (p === 'demo') return t('statusDemo');
  const names = { gemini: 'Gemini', openai: 'GPT', anthropic: 'Claude', groq: 'Groq', openrouter: 'OpenRouter' };
  return (names[p] || p) + ' · ' + t('statusOnline');
}

/* ---------------- fonts ---------------- */
const FONTS = {
  hajar: "'Hajar', 'RTL Hajar', 'هاجر', 'Amiri', 'Tajawal', serif",
  amiri: "'Amiri', 'Hajar', 'Tajawal', serif",
  tajawal: "'Tajawal', 'Hajar', 'Amiri', sans-serif",
  cairo: "'Cairo', 'Tajawal', 'Amiri', sans-serif",
  noto: "'Noto Naskh Arabic', 'Amiri', 'Tajawal', serif",
};
function applyFont() {
  document.documentElement.style.setProperty('--font-arabic', FONTS[settings.fontFamily] || FONTS.hajar);
}

/* ---------------- markdown ---------------- */
function escapeHtml(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

function inlineMd(s) {
  return s
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
}

function mdToHtml(text) {
  const lines = String(text).split('\n');
  let html = [], inUl = false, inOl = false, inCode = false, codeBuf = [];
  for (const raw of lines) {
    if (/^\s*```/.test(raw)) {
      if (inCode) { html.push('<pre><code>' + escapeHtml(codeBuf.join('\n')) + '</code></pre>'); codeBuf = []; inCode = false; }
      else inCode = true;
      continue;
    }
    if (inCode) { codeBuf.push(raw); continue; }
    const l = escapeHtml(raw);
    const h = l.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      if (inUl) { html.push('</ul>'); inUl = false; }
      if (inOl) { html.push('</ol>'); inOl = false; }
      html.push(`<h${h[1].length}>${inlineMd(h[2])}</h${h[1].length}>`);
      continue;
    }
    if (/^[-*]\s+/.test(l)) {
      if (!inUl) { if (inOl) { html.push('</ol>'); inOl = false; } html.push('<ul>'); inUl = true; }
      html.push('<li>' + inlineMd(l.replace(/^[-*]\s+/, '')) + '</li>');
      continue;
    }
    if (/^\d+[.)]\s+/.test(l)) {
      if (!inOl) { if (inUl) { html.push('</ul>'); inUl = false; } html.push('<ol>'); inOl = true; }
      html.push('<li>' + inlineMd(l.replace(/^\d+[.)]\s+/, '')) + '</li>');
      continue;
    }
    if (inUl) { html.push('</ul>'); inUl = false; }
    if (inOl) { html.push('</ol>'); inOl = false; }
    if (/^&gt;\s?/.test(l)) { html.push('<blockquote>' + inlineMd(l.replace(/^&gt;\s?/, '')) + '</blockquote>'); continue; }
    if (l.trim() === '') continue;
    html.push('<p>' + inlineMd(l) + '</p>');
  }
  if (inCode) html.push('<pre><code>' + escapeHtml(codeBuf.join('\n')) + '</code></pre>');
  if (inUl) html.push('</ul>');
  if (inOl) html.push('</ol>');
  return html.join('');
}

/* ---------------- rendering ---------------- */
function currentConv() {
  if (!currentId || !convs[currentId]) {
    const id = 'c' + Date.now().toString(36);
    convs[id] = { id, title: t('chatTitleNew'), createdAt: Date.now(), messages: [] };
    currentId = id;
    saveConvs(); saveCurrent();
  }
  return convs[currentId];
}

function scrollToBottom() {
  const m = $('messages');
  m.scrollTop = m.scrollHeight;
}

function renderChips() {
  const wrap = $('chips');
  if (!wrap) return;
  wrap.innerHTML = '';
  t('chips').forEach((c) => {
    const b = document.createElement('button');
    b.className = 'chip';
    b.textContent = c.label;
    b.addEventListener('click', () => sendMessage(c.q));
    wrap.appendChild(b);
  });
}

function messageEl(msg) {
  const wrap = document.createElement('div');
  wrap.className = 'msg ' + (msg.role === 'user' ? 'user' : 'ai');
  wrap.id = 'msg-' + msg.id;
  const avatarLetter = msg.role === 'user' ? t('you') : t('ai');
  wrap.innerHTML = `
    <div class="avatar ${msg.role === 'user' ? 'user-av' : 'ai-av'}">${avatarLetter}</div>
    <div class="msg-col">
      <div class="bubble">${msg.content ? mdToHtml(msg.content) : '<div class="typing"><span></span><span></span><span></span></div>'}</div>
      <div class="msg-meta">${msg.time || nowTime()}</div>
    </div>`;
  return wrap;
}

function renderAll() {
  const conv = currentConv();
  const m = $('messages');
  m.innerHTML = '';
  const empty = document.createElement('div');
  empty.className = 'empty-state';
  empty.id = 'emptyState';
  empty.innerHTML = `
    <div class="empty-orb">${t('ai')}</div>
    <h2 class="empty-title">${t('emptyTitle')}</h2>
    <p class="empty-sub">${t('emptySub')}</p>
    <button class="big-mic" id="bigMicBtn" type="button">
      <span class="big-mic-icon">🎙️</span><span>${t('bigMicLabel')}</span>
    </button>
    <div class="chips" id="chips"></div>`;
  m.appendChild(empty);
  renderChips();
  const bm = document.getElementById('bigMicBtn');
  if (bm) bm.addEventListener('click', () => enterVoiceMode());
  conv.messages.forEach((msg) => m.appendChild(messageEl(msg)));
  if (conv.messages.length) empty.style.display = 'none';
  $('chatTitle').textContent = (conv.title && conv.title !== t('chatTitleNew')) ? conv.title : 'hiwar';
  scrollToBottom();
}

function updateBubble(msgId, text, typing) {
  const el = document.getElementById('msg-' + msgId);
  if (!el) return;
  const b = el.querySelector('.bubble');
  if (typing) b.innerHTML = mdToHtml(text) + '<span class="caret"></span>';
  else b.innerHTML = text ? mdToHtml(text) : '<div class="typing"><span></span><span></span><span></span></div>';
  scrollToBottom();
}

function renderSidebar() {
  const list = $('convList');
  list.innerHTML = '';
  const items = Object.values(convs).sort((a, b) => b.createdAt - a.createdAt);
  if (!items.length) {
    const p = document.createElement('div');
    p.style.cssText = 'text-align:center;color:rgba(244,238,224,.4);font-size:13px;padding:20px 8px;';
    p.textContent = '—';
    list.appendChild(p);
    return;
  }
  items.forEach((c) => {
    const it = document.createElement('div');
    it.className = 'conv-item' + (c.id === currentId ? ' active' : '');
    it.innerHTML = `
      <span class="c-dot"></span>
      <span class="c-text">${escapeHtml((c.title && c.title !== t('chatTitleNew')) ? c.title : 'hiwar')}</span>
      <button class="c-del" title="حذف">✕</button>`;
    it.querySelector('.c-text').addEventListener('click', () => {
      currentId = c.id; saveCurrent(); renderAll();
      setSidebar(false);
    });
    it.querySelector('.c-del').addEventListener('click', (e) => {
      e.stopPropagation();
      delete convs[c.id];
      if (currentId === c.id) currentId = null;
      saveConvs(); saveCurrent();
      renderSidebar(); renderAll();
      toast(t('deleted'));
    });
    list.appendChild(it);
  });
}

/* ---------------- demo engine ---------------- */
function demoReply(messages) {
  const last = [...messages].reverse().find((m) => m.role === 'user');
  const q = (last ? last.content : '').trim();
  const ar = isArabic(q);
  const low = q.toLowerCase();

  if (ar) {
    if (/مرحبا|السلام|اهلا|أهلا|هاي|صباح الخير|مساء الخير/.test(q)) return 'أهلاً وسهلاً بك في «حوار» ✨ — يسعدني أن أرافقك. كيف يمكنني أن أخدمك اليوم؟';
    if (/كيف حالك|شلونك|اخبارك|أخبارك|عامل ايه/.test(q)) return 'أنا في أتمّ الحال، شكراً لسؤالك اللطيف 🌟 — وأنت، كيف يومك؟';
    if (/من انت|من أنت|عرف بنفسك|ما اسمك|وش اسمك/.test(q)) return 'أنا «حوار» — وكيل ذكاء اصطناعي فاخر، صُممت لأحاورك بلغتك، نصاً وصوتاً، بذكاءٍ وأناقة.';
    if (/شكرا|شكراً|تسلم|يعطيك العافية|مشكور/.test(q)) return 'العفو، هذا من دواعي سروري 💛 — إن احتجت شيئاً آخر فأنا هنا.';
    if (/نكتة|ضحكني|فكاهة|شي مضحك/.test(q)) return 'لماذا لا يتشاجر الذكاء الاصطناعي أبداً؟\n\nلأنه يفضّل دائماً «التوافق» على «الخلاف»! 😄';
    if (/قصيدة|شعر|بيت شعر/.test(q)) return 'سأهديك من وحْيِ القلب:\n\nحدّثتُ ليلي عن حوارٍ هادئٍ\nفإذا النجومُ على نوافذِه شُموع\nوالدهرُ ينسجُ من كلامِكَ نُورَهُ\nوالنفسُ تزهو والجمالُ بديع ✨';
    if (/ذكاء اصطناعي|الذكاء الاصطناعي|ai|تعلم آلي/.test(low)) return 'الذكاء الاصطناعي — ببساطة — أنظمة تتعلّم الأنماط من البيانات لتؤدي مهاماً تشبه الفهم البشري: كالمحادثة والترجمة والتحليل. وأنا واحدٌ منها، لكن بأناقةٍ ذهبية ✨';
    if (/الوضع التجريبي|وضع تجريبي|demo|مفتاح|api|الاعدادات|الإعدادات/.test(low)) return 'يمكنك ضبط كل شيء من **الإعدادات ⚙️**: اختيار المزوّد، الصوت، الخط، وغيرها. وستبقى تجربتك فاخرة دائماً!';
    if (/وداعا|وداعاً|مع السلامة|باي|الى اللقاء|إلى اللقاء/.test(q)) return 'في أمان الله، وإلى لقاءٍ قريب 🌙 — كان شرفاً لي أن أحاورك.';
    return `سؤالٌ جميل ✨\n\nدعني أفكّر معك في: «${q.slice(0, 60)}» — أخبرني المزيد عن التفاصيل التي تهمك لأعطيك أفضل إجابة.`;
  }

  if (/\b(hi|hello|hey|salam|assalamu|good (morning|evening|afternoon))\b/.test(low)) return "Welcome to Hiwar ✨ — I'm delighted to be here. How may I serve you today?";
  if (/how are you/.test(low)) return "I'm wonderful, thank you for asking 🌟 — and how is your day going?";
  if (/who are you|your name|about you|introduce/.test(low)) return "I'm **Hiwar** — a luxury AI agent, crafted for elegant conversations in text and voice.";
  if (/thank|thanks|great|awesome/.test(low)) return "You're most welcome 💛 — I'm always here for you.";
  if (/joke|funny|laugh/.test(low)) return "Why did the AI cross the road?\n\nBecause it had a neural net to get to the other side! 😄";
  if (/poem|poetry|verse/.test(low)) return "Let me offer you a short verse:\n\n*Whisper to the quiet night a word,*\n*and watch the stars lean close to hear;*\n*the world is woven of the things we say,*\n*so speak in gold, and hold it dear.* ✨";
  if (/artificial intelligence|\bai\b|machine learning/.test(low)) return "AI, simply put, is systems that learn patterns from data to perform human-like tasks — conversation, translation, analysis, and more. I'm one of them, dressed in gold ✨";
  if (/api key|settings|demo mode|unlock/.test(low)) return "You can tune everything in **Settings ⚙️** — provider, voice, font, and more. Your experience stays just as luxurious!";
  if (/\b(bye|goodbye|see you|farewell)\b/.test(low)) return "Farewell, and until we meet again 🌙 — it was a pleasure conversing with you.";
  return `What a lovely question ✨\n\nLet me think with you about “${q.slice(0, 60)}” — tell me more about the details you care about for the best answer.`;
}

/* ---------------- العقل المحلي (وضع الطوارئ بدون خادم) ---------------- */
function localBrain(text) {
  const q = String(text || '').trim();
  const ar = isArabic(q);
  const low = q.toLowerCase();

  // العمليات الحسابية البسيطة
  const math = low.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[x×]/g, '*').replace(/÷/g, '/').replace(/,/g, '');
  const m = math.match(/(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)/);
  if (m && !/[a-z]/i.test(low.replace(/[+\-*/x×÷\d\s.]/g, ''))) {
    let r;
    const a = parseFloat(m[1]), b = parseFloat(m[3]);
    if (m[2] === '+') r = a + b;
    else if (m[2] === '-') r = a - b;
    else if (m[2] === '*') r = a * b;
    else if (m[2] === '/') r = b === 0 ? null : a / b;
    if (r !== null && r !== undefined) {
      const val = Math.round(r * 10000) / 10000;
      return ar ? `ناتج ${m[1]} ${m[2] === '*' ? '×' : m[2]} ${m[3]} = ${val}` : `${m[1]} ${m[2]} ${m[3]} = ${val}`;
    }
  }

  // الوقت والتاريخ
  if (ar && /الوقت|الساعة|كم الساعة/.test(q)) {
    return 'الوقت الآن: ' + new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }) + ' — والتاريخ: ' + new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) + '.';
  }
  if (!ar && /time|date|today/.test(low)) {
    return 'Right now it is ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ' on ' + new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) + '.';
  }

  // عواصم (قاموس سريع)
  const caps = {
    'السعودية': 'الرياض', 'مصر': 'القاهرة', 'الامارات': 'أبوظبي', 'الإمارات': 'أبوظبي', 'الكويت': 'مدينة الكويت',
    'قطر': 'الدوحة', 'البحرين': 'المنامة', 'عمان': 'مسقط', 'الاردن': 'عمّان', 'الأردن': 'عمّان',
    'لبنان': 'بيروت', 'سوريا': 'دمشق', 'العراق': 'بغداد', 'فلسطين': 'القدس', 'اليمن': 'صنعاء',
    'ليبيا': 'طرابلس', 'تونس': 'تونس', 'الجزائر': 'الجزائر', 'المغرب': 'الرباط', 'السودان': 'الخرطوم',
    'تركيا': 'أنقرة', 'فرنسا': 'باريس', 'بريطانيا': 'لندن', 'امريكا': 'واشنطن', 'أمريكا': 'واشنطن',
    'الصين': 'بكين', 'اليابان': 'طوكيو', 'روسيا': 'موسكو', 'المانيا': 'برلين', 'ألمانيا': 'برلين',
    'ايطاليا': 'روما', 'إيطاليا': 'روما', 'اسبانيا': 'مدريد', 'إسبانيا': 'مدريد', 'كندا': 'أوتاوا',
    'الهند': 'نيودلهي', 'استراليا': 'كانبرا', 'أستراليا': 'كانبرا',
    'saudi arabia': 'Riyadh', 'egypt': 'Cairo', 'uae': 'Abu Dhabi', 'kuwait': 'Kuwait City',
    'qatar': 'Doha', 'bahrain': 'Manama', 'oman': 'Muscat', 'jordan': 'Amman', 'lebanon': 'Beirut',
    'syria': 'Damascus', 'iraq': 'Baghdad', 'france': 'Paris', 'uk': 'London', 'britain': 'London',
    'united states': 'Washington, D.C.', 'usa': 'Washington, D.C.', 'america': 'Washington, D.C.',
    'china': 'Beijing', 'japan': 'Tokyo', 'russia': 'Moscow', 'germany': 'Berlin', 'italy': 'Rome',
    'spain': 'Madrid', 'canada': 'Ottawa', 'india': 'New Delhi', 'australia': 'Canberra',
  };
  for (const [k, v] of Object.entries(caps)) {
    if (low.includes(k)) {
      return ar ? `عاصمة ${k} هي ${v}.` : `The capital of ${k} is ${v}.`;
    }
  }

  // تعريفات سريعة
  if (ar && /الذكاء الاصطناعي|ما هو الذكاء/.test(q)) return 'الذكاء الاصطناعي هو أنظمة حاسوبية تتعلّم من البيانات وتؤدي مهاماً تشبه الفهم البشري، كالمحادثة والترجمة والتحليل.';
  if (!ar && /artificial intelligence|what is ai/.test(low)) return 'Artificial intelligence refers to computer systems that learn patterns from data to perform human-like tasks such as conversation, translation, and analysis.';

  // تحيات
  if (ar && /مرحبا|السلام|اهلا|أهلا|هاي|صباح الخير|مساء الخير/.test(q)) return 'أهلاً وسهلاً بك 🌹 — أنا في وضع الطوارئ المحلي حالياً، لكنني سأعود بكامل ذكائي فور عودة الاتصال بالخادم.';
  if (!ar && /\b(hi|hello|hey|good morning|good evening)\b/.test(low)) return 'Hello 🌹 — I am currently in emergency local mode, but I will return with full intelligence as soon as the server reconnects.';

  // رسالة افتراضية صادقة
  if (ar) {
    return 'أنا أعمل الآن في وضع الطوارئ المحلي ⚡ بدون اتصال بالخادم، لذا لا أستطيع الرد الكامل على هذا السؤال.\n\nسيعود الذكاء الاصطناعي الكامل تلقائياً فور عودة الاتصال — جرّب إعادة الإرسال بعد لحظات، أو اسألني عن: الوقت، عاصمة دولة، أو عملية حسابية بسيطة.';
  }
  return "I'm currently in emergency local mode ⚡ with no server connection, so I can't fully answer this.\n\nFull AI will resume automatically once the connection returns — try again shortly, or ask me for the time, a country's capital, or a simple calculation.";
}

/* ---------------- messaging ---------------- */
function setInputEnabled(on) {
  $('sendBtn').disabled = !on;
  $('sendBtn').style.opacity = on ? '1' : '0.55';
}

function buildPayload() {
  const conv = currentConv();
  const msgs = [];
  let sys = settings.systemPrompt && settings.systemPrompt.trim();
  // عند تفعيل القراءة الصوتية، نوجّه النموذج لإجابات منطوقة فصيحة
  if (settings.autoSpeak) {
    const spokenHint = lang === 'ar'
      ? 'ستُقرأ إجابتك صوتياً بصوت بشري، فأجب بجمل عربية فصيحة وواضحة وقصيرة، وتجنّب الرموز والجداول والقوائم الطويلة.'
      : 'Your answer will be read aloud with a natural human voice, so reply in clear, well-structured spoken sentences and avoid symbols, tables, and long lists.';
    sys = sys ? (sys + '\n' + spokenHint) : spokenHint;
  }
  if (sys) msgs.push({ role: 'system', content: sys });
  conv.messages.forEach((m) => { if (m.content && m.content.trim()) msgs.push({ role: m.role, content: m.content }); });
  return msgs;
}

function friendlyError(msg) {
  const s = String(msg || '').toLowerCase();
  if (/SERVER_DOWN/.test(s)) return t('serverDown');
  if (/KEY_MISSING/.test(s)) return t('keyMissing');
  if (/credit balance|insufficient.*credit|رصيد|منخفض/.test(s)) return t('lowCredit');
  if (/insufficient_quota|insufficient quota|quota|الحصة|الحد اليومي|rate.?limit|429|too many/.test(s)) return t('quota');
  if (/401|403|invalid api key|incorrect api key|unauthorized|not authorized|api key|المفتاح غير|غير مصرّح|غير مصرح/.test(s)) return t('badKey');
  if (/404|model.*not found|not_found|does not exist|invalid model|غير متاح|غير متوفر/.test(s)) return t('badModel');
  if (/انقطع البث|تعذّر الاتصال|تعذر الاتصال|تحقّق من الإنترنت|تحقق من الإنترنت|network/.test(s)) return t('errorOccurred');
  return null;
}

async function sendMessage(text) {
  text = (text || '').trim();
  if (!text) return;
  if (streaming) { toast(t('busy')); return; }

  const conv = currentConv();
  const empty = $('emptyState');
  if (empty) empty.style.display = 'none';

  const userMsg = { id: uid(), role: 'user', content: text, time: nowTime() };
  conv.messages.push(userMsg);
  $('messages').appendChild(messageEl(userMsg));
  if (!conv.title || conv.title === t('chatTitleNew')) {
    conv.title = text.slice(0, 32);
    $('chatTitle').textContent = conv.title;
    renderSidebar();
  }
  scrollToBottom();

  const aiMsg = { id: uid(), role: 'assistant', content: '', time: nowTime() };
  conv.messages.push(aiMsg);
  $('messages').appendChild(messageEl(aiMsg));
  scrollToBottom();

  streaming = true;
  setInputEnabled(false);
  $('sendBtn').innerHTML = '<svg viewBox="0 0 24 24" width="19" height="19"><path fill="currentColor" d="M6 6h12v12H6z"/></svg>';

  try {
    let full = '';
    if (settings.provider === 'demo') {
      full = await streamDemo(aiMsg.id, demoReply(buildPayload()));
    } else {
      // المفتاح الفارغ مسموح: الخادم يستخدم GEMINI_API_KEY من بيئة الاستضافة
      full = await streamServer(aiMsg.id);
    }
    aiMsg.content = full;
    updateBubble(aiMsg.id, full, false);
    conv.createdAt = Date.now();
    saveConvs();
    renderSidebar();
    if (settings.autoSpeak && full) speak(full);
  } catch (e) {
    // إصلاح ذاتي متعدد المستويات:
    // 1) حصة ممتلئة → عدّ تنازلي وإعادة محاولة تلقائية
    // 2) الخادم غير متصل → وضع طوارئ محلي يُجيب ويُنبّه (ثم يعود الذكاء الكامل تلقائياً)
    // 3) خطأ إعداد (مفتاح/نموذج) → رسالة صادقة واضحة
    if (e && e.retryAfter) {
      await autoRetryQuota(aiMsg, e.retryAfter);
    } else {
      const raw = (e && e.message) || t('errorOccurred');
      const friendly = friendlyError(raw) || raw;
      const offline = raw === 'SERVER_DOWN' || /serverDown|الخادم غير|غير متصل/.test(friendly);
      if (offline) {
        const local = localBrain(text);
        aiMsg.content = '⚡ ' + t('offlineMode') + '\n\n' + local + '\n\n_' + t('offlineHint') + '_';
        updateBubble(aiMsg.id, aiMsg.content, false);
        if (settings.autoSpeak && local) speak(local);
      } else {
        toast(friendly, 'error');
        aiMsg.content = '⚠️ ' + friendly;
        updateBubble(aiMsg.id, aiMsg.content, false);
      }
    }
    conv.createdAt = Date.now();
    saveConvs();
    renderSidebar();
  } finally {
    streaming = false;
    setInputEnabled(true);
    $('sendBtn').innerHTML = '<svg viewBox="0 0 24 24" width="19" height="19"><path fill="currentColor" d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>';
  }
}

async function autoRetryQuota(aiMsg, retryAfter) {
  // عدّ تنازلي مرئي ثم إعادة محاولة تلقائية (حتى 4 محاولات)
  for (let attempt = 1; attempt <= 4; attempt++) {
    let left = Math.max(1, Math.ceil(retryAfter));
    while (left > 0) {
      aiMsg.content = '⏳ ' + t('quotaCountdown').replace('{n}', left);
      updateBubble(aiMsg.id, aiMsg.content, false);
      await sleepMs(1000);
      left--;
    }
    try {
      const full = await streamServer(aiMsg.id);
      aiMsg.content = full;
      updateBubble(aiMsg.id, full, false);
      return;
    } catch (e2) {
      if (e2 && e2.retryAfter) { retryAfter = e2.retryAfter; continue; }
      const f2 = friendlyError((e2 && e2.message) || '') || (e2 && e2.message);
      aiMsg.content = '⚠️ ' + f2;
      updateBubble(aiMsg.id, aiMsg.content, false);
      return;
    }
  }
  aiMsg.content = '⚠️ ' + t('quota');
  updateBubble(aiMsg.id, aiMsg.content, false);
}

function streamDemo(msgId, full) {
  return new Promise((resolve) => {
    const tokens = full.split(/(\s+)/);
    let acc = '', i = 0, cancelled = false;
    streamCancel = () => { cancelled = true; };
    const step = () => {
      if (cancelled) { streamCancel = null; resolve(acc); return; }
      if (i >= tokens.length) { streamCancel = null; resolve(acc); return; }
      const burst = 1 + Math.floor(Math.random() * 2);
      for (let k = 0; k < burst && i < tokens.length; k++) acc += tokens[i++];
      updateBubble(msgId, acc, true);
      setTimeout(step, 14 + Math.random() * 30);
    };
    step();
  });
}

async function postChat(msgs, cfg) {
  // إعادة محاولة تلقائية عند أخطاء مؤقتة (شبكة/خادم مشغول)
  let lastErr = null;
  for (let i = 0; i < 3; i++) {
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: msgs, config: cfg }),
      });
      if (res.ok) return res;
      const txt = await res.text().catch(() => '');
      lastErr = new Error('HTTP ' + res.status + (txt ? ' — ' + txt.slice(0, 200) : ''));
    } catch (e) {
      lastErr = e;
    }
    if (i < 2) await sleepMs(800 * (i + 1));
  }
  throw lastErr || new Error('SERVER_DOWN');
}

async function streamServer(msgId) {
  const msgs = buildPayload();
  const cfg = {
    provider: settings.provider,
    baseUrl: settings.baseUrl,
    apiKey: settings.apiKey,
    model: settings.model,
  };
  let res;
  try {
    res = await postChat(msgs, cfg);
  } catch (e) {
    // إن كان خطأ HTTP صريحاً فاحتفظ به، وإلا فالخادم غير متصل
    if (e && e.message && /^HTTP /.test(e.message)) throw e;
    throw new Error('SERVER_DOWN');
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '', acc = '';
  streamCancel = () => { try { reader.cancel(); } catch {} };
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let idx;
    while ((idx = buf.indexOf('\n')) !== -1) {
      const line = buf.slice(0, idx).replace(/\r$/, '');
      buf = buf.slice(idx + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (data === '[DONE]') { streamCancel = null; return acc; }
      try {
        const j = JSON.parse(data);
        if (j.error) {
          const e = new Error(j.error);
          if (j.retryAfter) e.retryAfter = j.retryAfter;
          throw e;
        }
        if (j.notice) toast(j.notice, 'success');
        if (j.t) { acc += j.t; updateBubble(msgId, acc, true); }
      } catch (e) { if (e && e.message && !(e instanceof SyntaxError)) { streamCancel = null; throw e; } }
    }
  }
  streamCancel = null;
  return acc;
}

/* ---------------- speech (نطق بشري فصيح) ---------------- */
function getVoice() {
  if (!voices.length && 'speechSynthesis' in window) voices = window.speechSynthesis.getVoices();
  // الصوت الذي اختاره المستخدم له الأولوية القصوى
  if (settings.voiceURI) {
    const exact = voices.find((v) => v.voiceURI === settings.voiceURI);
    if (exact) return exact;
  }
  const base = settings.voiceLang.toLowerCase().split('-')[0];
  const pool = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith(base));
  const isAr = base === 'ar';
  // أصوات عصبية بشريّة معروفة تُفضَّل تلقائياً لنطق سليم
  const preferred = isAr
    ? ['google', 'zariyah', 'majed', 'hoda', 'salmah', 'maged', 'hamad', 'laila', 'tarik', 'nayla', 'natural', 'neural']
    : ['google', 'natural', 'neural', 'aria', 'jenny', 'guy', 'sonia', 'libby', 'ryan', 'samantha'];
  let best = null;
  for (const key of preferred) {
    const hit = pool.find((v) => v.name.toLowerCase().includes(key));
    if (hit) { best = hit; break; }
  }
  if (!best) best = pool.find((v) => v.lang.toLowerCase() === settings.voiceLang.toLowerCase()) || pool[0];
  return best || null;
}

function cleanForSpeech(text) {
  // يزيل الرموز والروابط والإيموجي حتى يُنطق النص بسلاسة دون أخطاء لفظ
  let s = String(text || '');
  s = s.replace(/```[\s\S]*?```/g, ' ');       // كتل الشيفرة
  s = s.replace(/`([^`]*)`/g, '$1');           // شيفرة سطرية
  s = s.replace(/!\[[^\]]*\]\([^)]*\)/g, ' '); // صور
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1'); // روابط → نصّها
  s = s.replace(/https?:\/\/\S+/g, ' ');       // روابط عارية
  s = s.replace(/[*_~>#|]/g, '');              // رموز Markdown
  try { s = s.replace(/\p{Extended_Pictographic}/gu, ''); } catch {}
  s = s.replace(/[<>{}[\]()\\]/g, ' ');
  s = s.replace(/[.…]{2,}/g, '.');
  s = s.replace(/\s+/g, ' ');
  s = s.replace(/\s+([,،:;؟?!.])/g, '$1');
  return s.trim();
}

function normalizeArabicTokens(s) {
  // يمنع الأخطاء اللفظية للكلمات اللاتينية داخل النص العربي (ينطقها صحيحة)
  const map = [
    [/chatgpt/gi, 'تشات جي بي تي'],
    [/gpt/gi, 'جي بي تي'],
    [/hiwar/gi, 'حوار'],
    [/\bai\b/gi, 'ذكاء اصطناعي'],
    [/\bapi\b/gi, 'إيه بي آي'],
    [/\bok\b/gi, 'أوكي'],
    [/\bpdf\b/gi, 'بي دي إف'],
    [/\burl\b/gi, 'رابط'],
    [/\bwww\b/gi, 'دبليو دبليو دبليو'],
    [/\bhttp\b/gi, 'إتش تي تي بي'],
    [/\bemail\b/gi, 'إيميل'],
    [/\bapp\b/gi, 'تطبيق'],
    [/\bgoogle\b/gi, 'جوجل'],
    [/\byoutube\b/gi, 'يوتيوب'],
    [/\bwhatsapp\b/gi, 'واتساب'],
    [/\binstagram\b/gi, 'إنستغرام'],
    [/\bfacebook\b/gi, 'فيسبوك'],
    [/\btwitter\b/gi, 'تويتر'],
    [/\bgithub\b/gi, 'غيت هب'],
    [/\biphone\b/gi, 'آيفون'],
    [/\bandroid\b/gi, 'أندرويد'],
    [/\bwindows\b/gi, 'ويندوز'],
    [/\bupdate\b/gi, 'تحديث'],
    [/\bdownload\b/gi, 'تحميل'],
    [/\bsettings\b/gi, 'الإعدادات'],
  ];
  for (const [re, ar] of map) s = s.replace(re, ar);
  return s;
}

function prepareSpeech(text) {
  let s = cleanForSpeech(text);
  // إن كانت لغة النطق عربية، حوّل الرموز اللاتينية إلى نطق عربي صحيح
  if ((settings.voiceLang || '').toLowerCase().startsWith('ar')) s = normalizeArabicTokens(s);
  return s;
}

function chunkText(text, maxLen) {
  // تقسيم النص إلى جمل قصيرة حتى لا يقطع Chrome النطق بعد ~15 ثانية
  maxLen = maxLen || 150;
  const sentences = String(text).replace(/([.!?؟۔])\s+/g, '$1\n').split('\n').map((s) => s.trim()).filter(Boolean);
  const chunks = [];
  let cur = '';
  const push = (s) => { if (s.trim()) chunks.push(s.trim()); };
  for (const s of sentences) {
    if (s.length > maxLen) {
      if (cur) { push(cur); cur = ''; }
      const words = s.split(' ');
      let piece = '';
      for (const w of words) {
        if ((piece + ' ' + w).trim().length > maxLen) { push(piece); piece = w; }
        else piece = (piece ? piece + ' ' : '') + w;
      }
      if (piece) push(piece);
    } else if ((cur + ' ' + s).trim().length > maxLen) {
      push(cur); cur = s;
    } else {
      cur = (cur ? cur + ' ' : '') + s;
    }
  }
  push(cur);
  return chunks.length ? chunks : [String(text).trim()];
}

function clearSpeakQueue() {
  speakQueue = [];
  speakingNow = false;
}

function afterSpeech() {
  hideVoiceStatus();
  // في وضع المحادثة الصوتية المستمرة، استمع من جديد بعد انتهاء القراءة
  if (settings.voiceChatMode && settings.autoSpeak && !streaming) {
    setTimeout(() => { if (!streaming && !micListening && !isSpeaking()) startListening(); }, 600);
  }
}

function isSpeaking() {
  if (speakingNow) return true;
  if (currentAudio) return true;
  try { if (window.speechSynthesis && window.speechSynthesis.speaking) return true; } catch {}
  return false;
}

/* ---- محرك الجهاز (speechSynthesis) ---- */
function speakNext() {
  if (!speakQueue.length) {
    speakingNow = false;
    afterSpeech();
    return;
  }
  speakingNow = true;
  const chunk = speakQueue.shift();
  const u = new SpeechSynthesisUtterance(chunk);
  u.lang = settings.voiceLang;
  u.rate = settings.rate;
  u.pitch = settings.pitch;
  const v = getVoice();
  if (v) u.voice = v;
  u.onstart = () => showVoiceStatus('speaking', t('speaking'));
  u.onend = () => speakNext();
  u.onerror = (e) => {
    if (e && e.error && e.error !== 'interrupted' && e.error !== 'canceled') toast(t('ttsFailed'), 'error');
    speakNext(); // تابع بقية الجمل رغم الخطأ
  };
  // مهلة قصيرة تمنع ابتلاع المتصفح للصوت عند تتابع الجمل
  setTimeout(() => { try { window.speechSynthesis.speak(u); } catch {} }, 40);
}

function speakSystem(clean) {
  if (!('speechSynthesis' in window)) { toast(t('ttsNotSupported'), 'error'); return; }
  try { window.speechSynthesis.cancel(); } catch {}
  clearSpeakQueue();
  speakQueue = chunkText(clean, 150);
  speakNext();
}

/* ---- محرك Google البشري (عبر الخادم، نطق فصيح بالحركات) ---- */
async function playTTSAudio(chunk) {
  const url = '/api/tts?text=' + encodeURIComponent(chunk) + '&lang=' + encodeURIComponent(settings.voiceLang);
  const res = await fetch(url, { cache: 'default' });
  if (!res.ok) throw new Error('tts ' + res.status);
  const blob = await res.blob();
  if (!blob || blob.size < 200) throw new Error('tts empty');
  const audioUrl = URL.createObjectURL(blob);
  await new Promise((resolve, reject) => {
    const a = new Audio(audioUrl);
    currentAudio = a;
    a.onended = () => { URL.revokeObjectURL(audioUrl); if (currentAudio === a) currentAudio = null; resolve(); };
    a.onerror = () => { URL.revokeObjectURL(audioUrl); if (currentAudio === a) currentAudio = null; reject(new Error('audio error')); };
    a.play().catch(() => { if (currentAudio === a) currentAudio = null; reject(new Error('audio blocked')); });
  });
}

async function speakGoogle(clean) {
  stopSpeaking();               // يوقف أي تشغيل سابق ويرفع الجيل
  const gen = speechGen;
  const chunks = chunkText(clean, 170);
  showVoiceStatus('speaking', t('speaking'));
  try {
    for (const c of chunks) {
      if (speechGen !== gen) return;   // أُلغي التشغيل
      await playTTSAudio(c);
    }
    if (speechGen !== gen) return;
    afterSpeech();
  } catch (e) {
    if (speechGen !== gen) return;
    // تعذّر المحرك السحابي → التحويل تلقائياً لمحرك الجهاز (بدون إنترنت)
    speakSystem(clean);
  }
}

function speak(text) {
  const clean = prepareSpeech(text);
  if (!clean) return;
  if (settings.voiceEngine === 'google') speakGoogle(clean);
  else speakSystem(clean);
}

function stopSpeaking() {
  speechGen++;                  // يوقف أي تشغيل جارٍ (مهما كان المحرك)
  clearSpeakQueue();
  if (currentAudio) { try { currentAudio.pause(); currentAudio.src = ''; } catch {} currentAudio = null; }
  if ('speechSynthesis' in window) { try { window.speechSynthesis.cancel(); } catch {} }
}

function showVoiceStatus(mode, text) {
  const el = $('voiceStatus');
  el.hidden = false;
  $('voiceStatusText').textContent = text;
  if ($('composer')) $('composer').classList.toggle('rec', mode === 'listening');
}
function hideVoiceStatus() {
  $('voiceStatus').hidden = true;
  if ($('composer')) $('composer').classList.remove('rec');
}

/* ---------------- وضع المحادثة الصوتية المستمرة (بدون كتابة) ---------------- */
function applyVoiceModeUI() {
  const on = !!settings.voiceChatMode;
  const banner = $('voiceModeBanner');
  if (banner) banner.hidden = !on;
  const vmb = $('voiceModeBannerText');
  if (vmb) vmb.textContent = t('voiceModeBannerOn');
  const bm = $('voiceModeBtn');
  if (bm) bm.classList.toggle('voice-on', on);
  $('voiceToggleBtn').classList.toggle('voice-on', settings.autoSpeak);
  const mb = $('micBtn');
  if (mb) mb.classList.toggle('idle-listen', on);
}

function enterVoiceMode() {
  if (streaming) { toast(t('busy')); return; }
  settings.voiceChatMode = true;
  settings.autoSpeak = true;
  saveSettings();
  applyVoiceModeUI();
  toast(t('voiceModeOn'), 'success');
  stopSpeaking();
  if (recognition) { try { recognition.abort(); } catch {} recognition = null; }
  speak(t('voiceGreeting'));
  // احتياط: إذا لم يتوفر نطق صوتي، ابدأ الاستماع مباشرة بعد لحظة
  setTimeout(() => {
    if (settings.voiceChatMode && !streaming && !recognition && !isSpeaking()) {
      startListening();
    }
  }, 1800);
}

function exitVoiceMode() {
  settings.voiceChatMode = false;
  saveSettings();
  applyVoiceModeUI();
  stopSpeaking();
  if (recognition) { try { recognition.abort(); } catch {} recognition = null; }
  micListening = false;
  noSpeechRetries = 0;
  hideVoiceStatus();
  toast(t('voiceModeOff'), 'success');
}

function toggleVoiceMode() {
  if (settings.voiceChatMode) exitVoiceMode();
  else enterVoiceMode();
}

async function ensureMicPermission() {
  // يطلب إذن الميكروفون صراحةً حتى تظهر نافذة السماح في المتصفح
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return 'ok';
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((tr) => tr.stop());
    return 'ok';
  } catch (e) {
    const n = e && e.name;
    if (n === 'NotAllowedError' || n === 'PermissionDeniedError' || n === 'SecurityError') return 'denied';
    return 'ok';
  }
}

async function startListening() {
  if (streaming) { toast(t('busy')); return; }
  if (micListening) return;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { toast(t('micNotSupported'), 'error'); return; }

  // طلب الإذن أول مرة فقط — تظهر نافذة السماح في Chrome/Edge
  if (!micPermissionAsked) {
    micPermissionAsked = true;
    toast(t('micWaiting'));
    const perm = await ensureMicPermission();
    if (perm === 'denied') { toast(t('micDenied'), 'error'); return; }
  }

  if (recognition) { try { recognition.abort(); } catch {} recognition = null; }
  stopSpeaking();

  recognition = new SR();
  recognition.lang = settings.voiceLang;
  recognition.interimResults = true;
  recognition.continuous = false;
  recognition.maxAlternatives = 1;
  let finalText = '';

  recognition.onstart = () => {
    micListening = true;
    $('micBtn').classList.add('recording');
    showVoiceStatus('listening', t('listening'));
  };
  recognition.onresult = (e) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) finalText += r[0].transcript;
      else interim += r[0].transcript;
    }
    const live = (finalText + ' ' + interim).trim();
    $('input').value = live;
    autoResize($('input'));
    // اعرض كلامك الحي في شريط الحالة أيضاً
    const st = $('voiceStatusText');
    if (st && !$('voiceStatus').hidden) st.textContent = live ? ('🎙️ ' + live) : t('listening');
  };
  const watchdog = setTimeout(() => {
    if (recognition) { try { recognition.stop(); } catch {} }
  }, 15000);

  const finishListening = () => {
    clearTimeout(watchdog);
    micListening = false;
    $('micBtn').classList.remove('recording');
    hideVoiceStatus();
    const text = $('input').value.trim();
    recognition = null;
    if (text) {
      noSpeechRetries = 0;
      $('input').value = ''; autoResize($('input'));
      sendMessage(text);
      return true;
    }
    return false;
  };

  recognition.onend = () => {
    const sent = finishListening();
    // Chrome يوقف الاستماع تلقائياً بعد ~60 ثانية صمت — نعيد التشغيل بحذر
    if (!sent && settings.voiceChatMode && noSpeechRetries < 3) {
      noSpeechRetries++;
      setTimeout(() => { if (settings.voiceChatMode && !streaming && !micListening) startListening(); }, 900);
    }
  };
  recognition.onerror = (e) => {
    clearTimeout(watchdog);
    micListening = false;
    $('micBtn').classList.remove('recording');
    hideVoiceStatus();
    recognition = null;
    const code = e && e.error;
    // لا تعد المحاولة أبداً عند رفض الإذن
    if (code === 'not-allowed' || code === 'service-not-allowed') { toast(t('micDenied'), 'error'); return; }
    if (code === 'no-speech') {
      if (settings.voiceChatMode && noSpeechRetries < 3) {
        noSpeechRetries++;
        setTimeout(() => { if (settings.voiceChatMode && !streaming && !micListening) startListening(); }, 900);
        return;
      }
      toast(t('micNoSpeech'), 'error');
      return;
    }
    if (code === 'network') {
      toast(t('micNetwork'), 'error');
      if (settings.voiceChatMode && noSpeechRetries < 3) {
        noSpeechRetries++;
        setTimeout(() => { if (settings.voiceChatMode && !streaming && !micListening) startListening(); }, 2000);
      }
      return;
    }
    const map = { 'audio-capture': 'micAudioCapture', 'language-not-supported': 'micLang' };
    const key = map[code];
    if (key) toast(t(key), 'error');
  };

  try {
    recognition.start();
  } catch (err) {
    micListening = false;
    toast(t('micNotSupported'), 'error');
    $('micBtn').classList.remove('recording');
    hideVoiceStatus();
  }
}

/* ---------------- navigation ---------------- */
function openChat(focusVoice) {
  $('landing').hidden = true;
  $('chat').hidden = false;
  renderAll();
  renderSidebar();
  setSidebar(false);
  if (focusVoice) {
    // الدخول عبر زر "محادثة صوتية" يشغّل الوضع المستمر + تحية صوتية + استماع تلقائي
    enterVoiceMode();
  }
}
function openLanding() {
  stopSpeaking();
  if (recognition) { try { recognition.abort(); } catch {} recognition = null; }
  micListening = false;
  $('chat').hidden = true;
  $('landing').hidden = false;
}

/* ---------------- settings modal ---------------- */
function populateVoices() {
  const sel = $('voiceSelect');
  sel.innerHTML = '';
  if (!voices.length && 'speechSynthesis' in window) voices = window.speechSynthesis.getVoices();
  const base = settings.voiceLang.toLowerCase().split('-')[0];
  const pool = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith(base));
  const shown = pool.length ? pool : voices;
  if (!shown.length) {
    const o = document.createElement('option');
    o.value = '';
    o.textContent = t('noVoices');
    sel.appendChild(o);
    return;
  }
  shown.forEach((v) => {
    const o = document.createElement('option');
    o.value = v.voiceURI;
    o.textContent = `${v.name} (${v.lang})`;
    sel.appendChild(o);
  });
  if (settings.voiceURI && [...sel.options].some((o) => o.value === settings.voiceURI)) {
    sel.value = settings.voiceURI;
  }
}

function refreshProviderFields() {
  const p = $('providerSelect').value;
  $('baseUrlGroup').hidden = p !== 'openai';
  $('apiKeyGroup').hidden = p === 'demo';
  $('modelGroup').hidden = p === 'demo';
  const m = $('modelInput');
  if (p === 'gemini') { if (!m.value) m.placeholder = 'gemini-3.6-flash'; }
  if (p === 'anthropic') { if (!m.value) m.placeholder = 'claude-3-5-sonnet-latest'; }
  if (p === 'openai') { if (!m.value) m.placeholder = 'gpt-4o-mini'; }
  if (p === 'groq') { if (!m.value) m.placeholder = 'llama-3.3-70b-versatile'; }
  if (p === 'openrouter') { if (!m.value) m.placeholder = 'meta-llama/llama-3.3-70b-instruct:free'; }
}

function openSettings() {
  let p = settings.provider;
  if (p === 'openai') {
    const b = (settings.baseUrl || '').toLowerCase();
    if (b.includes('groq')) p = 'groq';
    else if (b.includes('openrouter')) p = 'openrouter';
  }
  $('providerSelect').value = p;
  $('baseUrlInput').value = settings.baseUrl;
  $('apiKeyInput').value = settings.apiKey;
  $('modelInput').value = settings.model;
  $('systemPromptInput').value = settings.systemPrompt;
  $('autoSpeakInput').checked = settings.autoSpeak;
  $('voiceChatModeInput').checked = settings.voiceChatMode;
  $('voiceEngineSelect').value = settings.voiceEngine || 'google';
  $('voiceLangSelect').value = settings.voiceLang;
  $('rateInput').value = settings.rate;
  $('pitchInput').value = settings.pitch;
  $('fontSelect').value = settings.fontFamily || 'hajar';
  refreshProviderFields();
  populateVoices();
  $('settingsModal').hidden = false;
}

function closeSettings() { $('settingsModal').hidden = true; }

function saveSettingsFromModal() {
  const p = $('providerSelect').value;
  settings.apiKey = $('apiKeyInput').value.trim();
  settings.model = $('modelInput').value.trim();
  if (p === 'groq') {
    settings.provider = 'openai';
    settings.baseUrl = 'https://api.groq.com/openai/v1';
    if (!settings.model) settings.model = 'llama-3.3-70b-versatile';
  } else if (p === 'openrouter') {
    settings.provider = 'openai';
    settings.baseUrl = 'https://openrouter.ai/api/v1';
    if (!settings.model) settings.model = 'meta-llama/llama-3.3-70b-instruct:free';
  } else {
    settings.provider = p;
    settings.baseUrl = $('baseUrlInput').value.trim() || 'https://api.openai.com/v1';
    if (p === 'gemini' && !settings.model) settings.model = 'gemini-3.6-flash';
  }
  settings.systemPrompt = $('systemPromptInput').value;
  settings.autoSpeak = $('autoSpeakInput').checked;
  settings.voiceChatMode = $('voiceChatModeInput').checked;
  settings.voiceEngine = $('voiceEngineSelect').value || 'google';
  settings.voiceLang = $('voiceLangSelect').value;
  settings.voiceURI = $('voiceSelect').value;
  settings.rate = parseFloat($('rateInput').value);
  settings.pitch = parseFloat($('pitchInput').value);
  settings.fontFamily = $('fontSelect').value || 'hajar';
  saveSettings();
  applyFont();
  closeSettings();
  const st = $('statusText');
  if (st) st.textContent = updateStatusText();
  applyVoiceModeUI();
  toast(t('saved'), 'success');
}

/* ---------------- language ---------------- */
function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const k = el.getAttribute('data-i18n');
    el.textContent = t(k);
  });
  const input = $('input');
  if (input) input.placeholder = t('inputPlaceholder');
  const vtl = $('voiceTryLabel');
  if (vtl) vtl.textContent = t('voiceTryLabel');
  const lb = $('langBtnLabel');
  if (lb) lb.textContent = lang === 'ar' ? 'EN' : 'AR';
  const lbc = $('langBtnChatLabel');
  if (lbc) lbc.textContent = lang === 'ar' ? 'EN' : 'AR';
  const st = $('statusText');
  if (st) st.textContent = updateStatusText();
  const vmb = $('voiceModeBannerText');
  if (vmb) vmb.textContent = t('voiceModeBannerOn');
  const cf = $('composerFoot');
  if (cf) cf.textContent = t('composerFoot');
  renderChips();
  if (!$('chat').hidden) { renderAll(); renderSidebar(); }
  document.title = lang === 'ar' ? 'حوار — Hiwar AI' : 'Hiwar — Luxury AI Chat';
}

/* ---------------- composer ---------------- */
function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 150) + 'px';
}

/* ---------------- sidebar open/close ---------------- */
function setSidebar(open) {
  $('sidebar').classList.toggle('closed', !open);
  // الشريط طبقة فوق المحتوى دائماً، مع خلفية معتمة عند فتحه (لا يغطي الأزرار)
  $('sidebarScrim').classList.toggle('show', open);
}

/* ---------------- events ---------------- */
function bindEvents() {
  $('tryNowBtn').addEventListener('click', () => openChat(false));
  $('voiceTryBtn').addEventListener('click', () => openChat(true));
  $('brandBtn').addEventListener('click', openLanding);

  $('newChatBtn').addEventListener('click', () => { currentId = null; saveCurrent(); renderAll(); renderSidebar(); });
  $('clearAllBtn').addEventListener('click', () => {
    convs = {}; currentId = null;
    saveConvs(); saveCurrent();
    renderAll(); renderSidebar();
    toast(t('cleared'));
  });

  const toggleLang = () => {
    lang = lang === 'ar' ? 'en' : 'ar';
    localStorage.setItem('hiwar.lang', lang);
    applyLang();
  };
  $('langBtn').addEventListener('click', toggleLang);
  $('langBtnChat').addEventListener('click', toggleLang);

  $('settingsBtn').addEventListener('click', openSettings);
  $('settingsBtn2').addEventListener('click', openSettings);
  $('closeSettingsBtn').addEventListener('click', closeSettings);
  $('settingsModal').addEventListener('click', (e) => { if (e.target === $('settingsModal')) closeSettings(); });
  $('saveSettingsBtn').addEventListener('click', saveSettingsFromModal);
  $('resetSettingsBtn').addEventListener('click', () => {
    settings = { ...DEFAULT_SETTINGS };
    saveSettings();
    openSettings();
  });
  $('providerSelect').addEventListener('change', () => {
    $('modelInput').value = '';
    refreshProviderFields();
  });
  $('voiceLangSelect').addEventListener('change', populateVoices);

  $('sendBtn').addEventListener('click', () => {
    if (streaming) { if (streamCancel) streamCancel(); return; }
    sendMessage($('input').value);
    $('input').value = '';
    autoResize($('input'));
  });

  const input = $('input');
  input.addEventListener('input', () => autoResize(input));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input.value);
      input.value = '';
      autoResize(input);
    }
  });

  $('micBtn').addEventListener('click', startListening);
  $('voiceModeBtn').addEventListener('click', toggleVoiceMode);
  $('exitVoiceModeBtn').addEventListener('click', exitVoiceMode);
  $('voiceToggleBtn').addEventListener('click', () => {
    settings.autoSpeak = !settings.autoSpeak;
    saveSettings();
    $('voiceToggleBtn').classList.toggle('voice-on', settings.autoSpeak);
    toast(settings.autoSpeak ? t('voiceOn') : t('voiceOff'));
    if (!settings.autoSpeak) stopSpeaking();
  });
  $('stopVoiceBtn').addEventListener('click', () => {
    stopSpeaking();
    if (recognition) { try { recognition.abort(); } catch {} recognition = null; }
    micListening = false;
    hideVoiceStatus();
  });

  // الشريط الجانبي: فتح/إغلاق
  $('menuBtn').addEventListener('click', () => setSidebar($('sidebar').classList.contains('closed')));
  $('sidebarScrim').addEventListener('click', () => setSidebar(false));
  $('testVoiceBtn').addEventListener('click', () => {
    const sample = lang === 'ar'
      ? 'مرحباً بك في حوار، هذا اختبار لصوت المساعد.'
      : 'Hello, this is a test of the assistant voice.';
    speak(sample);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeSettings(); setSidebar(false); }
  });
}

/* ---------------- المراقبة الذاتية للاتصال ---------------- */
let healthDownNotified = false;

function setStatusDot(ok) {
  const dot = $('statusDot');
  if (!dot) return;
  if (ok) { dot.classList.add('ok'); dot.classList.remove('down'); }
  else { dot.classList.remove('ok'); dot.classList.add('down'); }
  const st = $('statusText');
  if (st) st.textContent = ok ? updateStatusText() : (lang === 'ar' ? 'غير متصل — إعادة الاتصال…' : 'Offline — reconnecting…');
}

function startHealthPoll() {
  const check = async () => {
    try {
      const r = await fetch('/api/health', { cache: 'no-store' });
      if (r.ok) {
        setStatusDot(true);
        if (healthDownNotified) { healthDownNotified = false; toast(t('serverBack'), 'success'); }
      } else {
        setStatusDot(false);
      }
    } catch {
      setStatusDot(false);
      healthDownNotified = true;
    }
  };
  check();
  setInterval(check, 15000);
}

function loadVoices() {
  if (!('speechSynthesis' in window)) { voices = []; return; }
  const get = () => { voices = window.speechSynthesis.getVoices(); };
  get();
  window.speechSynthesis.onvoiceschanged = get;
  // بعض المتصفحات تُحمّل الأصوات متأخراً
  if (!voices.length) { setTimeout(get, 500); setTimeout(get, 1500); }
}

/* ---------------- خدمة العمل دون اتصال (Service Worker) ---------------- */
function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  const secure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  if (!secure) return;
  try {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  } catch {}
}

/* ---------------- حماية شاملة من الأخطاء ---------------- */
window.addEventListener('error', (e) => {
  try { console.warn('hiwar ui error:', e && e.message); } catch {}
  try { if (e && e.preventDefault) e.preventDefault(); } catch {}
});
window.addEventListener('unhandledrejection', (e) => {
  try { console.warn('hiwar promise error:', e && e.reason); } catch {}
  try { if (e && e.preventDefault) e.preventDefault(); } catch {}
});

/* ---------------- boot ---------------- */
function boot() {
  applyLang();
  applyFont();
  bindEvents();
  loadVoices();
  startHealthPoll();
  applyVoiceModeUI();
  registerServiceWorker();
  // الشريط الجانبي مغلق افتراضياً في كل الأحجام حتى لا يغطي زر المايك والمحتوى
  setSidebar(false);
}

document.addEventListener('DOMContentLoaded', boot);
